package common;

public class Otp {

}
