
public class main {
public main() {
	System.out.println("ok");
}
}
